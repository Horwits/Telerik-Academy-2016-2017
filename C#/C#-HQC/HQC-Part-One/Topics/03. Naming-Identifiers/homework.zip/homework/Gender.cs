﻿namespace Humans
{
    public enum Gender
    {
        Man,
        Women
    }
}