﻿namespace Chef.Contracts
{
    public interface IVegetable
    {
        bool IsRotten { get; set; }
    }
}