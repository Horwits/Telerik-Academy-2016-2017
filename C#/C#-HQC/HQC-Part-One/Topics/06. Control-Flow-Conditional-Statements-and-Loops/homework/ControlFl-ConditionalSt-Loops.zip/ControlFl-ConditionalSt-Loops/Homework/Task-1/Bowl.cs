﻿namespace Chef
{
    internal class Bowl
    {
        public void Add(Vegetable carrot)
        {
            throw new System.NotImplementedException();
        }
    }
}