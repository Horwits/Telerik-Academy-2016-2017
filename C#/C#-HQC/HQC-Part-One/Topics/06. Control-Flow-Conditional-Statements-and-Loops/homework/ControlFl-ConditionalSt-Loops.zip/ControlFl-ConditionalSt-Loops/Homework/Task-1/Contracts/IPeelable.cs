﻿namespace Chef.Contracts
{
    public interface IPeelable
    {
        bool HasBeenPeeled { get; set; }
    }
}
